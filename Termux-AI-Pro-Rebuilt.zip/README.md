# Termux-AI-Pro (Rebuilt)

Run inside Termux:

```
chmod +x install.sh
./install.sh
termux-ai
```

Config stored at `~/.config/termux-ai-pro/config.json`.
